const allowedOrigins = ["http://localhost:3000", "http://localhost:8000", "https://test.taniq.co"];

module.exports = allowedOrigins;
